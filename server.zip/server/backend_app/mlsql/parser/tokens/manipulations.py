trainTokens = [
    'TRAIN',
    'WITH',
    'TRAINING_PROFILE'
]

utilityTokens = [
    'SET',
    'DEBUG',
    'AS'
]