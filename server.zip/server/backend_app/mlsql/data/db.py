from peewee import *
db = SqliteDatabase('definitions.db')